public class PowerSupply {
}
